import 'package:flutter/material.dart';
// Jaspreet Singh 221ADB045
// Food Item Model
class FoodItem {
  final String id;
  final String name;
  final double price;
  final String imageUrl;

  FoodItem({
    required this.id,
    required this.name,
    required this.price,
    required this.imageUrl,
  });
}

// Restaurant Model
class Restaurant {
  final String id;
  final String name;
  final List<FoodItem> menu;

  Restaurant({required this.id, required this.name, required this.menu});
}

// Cart Item Model
class CartItem {
  final FoodItem foodItem;
  int quantity;

  CartItem({required this.foodItem, this.quantity = 1});
}

// Main Application
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Food Delivery',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            textStyle: TextStyle(fontSize: 18),
          ),
        ),
      ),
      home: HomeScreen(),
    );
  }
}

// Home Screen
class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Restaurant> restaurants = [
    Restaurant(
      id: '1',
      name: 'Pizza Place',
      menu: [
        FoodItem(
          id: '1',
          name: 'Margherita Pizza',
          price: 9.99,
          imageUrl: 'lib/how-to-make-authentic-margherita-pizza-at-home-recipe-4.jpg',
        ),
        FoodItem(
          id: '2',
          name: 'Pepperoni Pizza',
          price: 11.99,
          imageUrl: 'lib/PeppPizza_600.jpg',
        ),
      ],
    ),
    Restaurant(
      id: '2',
      name: 'Burger Joint',
      menu: [
        FoodItem(
          id: '3',
          name: 'Cheeseburger',
          price: 7.99,
          imageUrl: 'lib/Cheeseburger.jpg',
        ),
        FoodItem(
          id: '4',
          name: 'Veggie Burger',
          price: 8.99,
          imageUrl: 'lib/maxresdefault.jpg',
        ),
      ],
    ),
  ];

  final List<CartItem> cart = [];

  void addToCart(FoodItem foodItem) {
    setState(() {
      CartItem? cartItem = cart.firstWhere(
        (item) => item.foodItem.id == foodItem.id,
        orElse: () => CartItem(foodItem: foodItem, quantity: 0),
      );
      if (cartItem.quantity == 0) {
        cart.add(cartItem);
      }
      cartItem.quantity += 1;
    });
  }

  void removeFromCart(FoodItem foodItem) {
    setState(() {
      CartItem? cartItem = cart.firstWhere(
        (item) => item.foodItem.id == foodItem.id,
        orElse: () => CartItem(foodItem: foodItem, quantity: 0),
      );
      if (cartItem.quantity > 0) {
        cartItem.quantity -= 1;
        if (cartItem.quantity == 0) {
          cart.remove(cartItem);
        }
      }
    });
  }

  void clearCart() {
    setState(() {
      cart.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Food Delivery'),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => CartScreen(cart: cart, clearCart: clearCart),
                ),
              );
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: restaurants.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(8),
            child: ListTile(
              title: Text(
                restaurants[index].name,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => RestaurantScreen(
                      restaurant: restaurants[index],
                      addToCart: addToCart,
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

// Restaurant Screen
class RestaurantScreen extends StatelessWidget {
  final Restaurant restaurant;
  final Function(FoodItem) addToCart;

  RestaurantScreen({required this.restaurant, required this.addToCart});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(restaurant.name),
      ),
      body: ListView.builder(
        itemCount: restaurant.menu.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(8),
            child: ListTile(
              leading: Image.network(
                restaurant.menu[index].imageUrl,
                width: 100,
                height: 100,
                fit: BoxFit.cover,
              ),
              title: Text(
                restaurant.menu[index].name,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '\$${restaurant.menu[index].price.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 16, color: Colors.green),
              ),
              trailing: IconButton(
                icon: Icon(Icons.add),
                onPressed: () {
                  addToCart(restaurant.menu[index]);
                },
              ),
            ),
          );
        },
      ),
    );
  }
}

// Cart Screen
class CartScreen extends StatelessWidget {
  final List<CartItem> cart;
  final VoidCallback clearCart;

  CartScreen({required this.cart, required this.clearCart});

  double get total {
    return cart.fold(0, (sum, item) => sum + item.foodItem.price * item.quantity);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cart'),
        actions: [
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: clearCart,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: cart.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: EdgeInsets.all(8),
                  child: ListTile(
                    leading: Image.network(
                      cart[index].foodItem.imageUrl,
                      width: 100,
                      height: 100,
                      fit: BoxFit.cover,
                    ),
                    title: Text(
                      cart[index].foodItem.name,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Quantity: ${cart[index].quantity}',
                      style: TextStyle(fontSize: 16),
                    ),
                    trailing: Text(
                      '\$${(cart[index].foodItem.price * cart[index].quantity).toStringAsFixed(2)}',
                      style: TextStyle(fontSize: 16, color: Colors.green),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Total: \$${total.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => UserInfoScreen(),
                  ),
                );
              },
              child: Text('Confirm Order'),
            ),
          ),
        ],
      ),
    );
  }
}

// User Info Screen
class UserInfoScreen extends StatefulWidget {
  @override
  _UserInfoScreenState createState() => _UserInfoScreenState();
}

class _UserInfoScreenState extends State<UserInfoScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();

  void _showSnackBar(BuildContext context, String message) {
    final snackBar = SnackBar(
      content: Text(message),
      duration: Duration(seconds: 4),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Information'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Name',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: _phoneController,
                decoration: InputDecoration(
                  labelText: 'Phone Number',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: _addressController,
                decoration: InputDecoration(
                  labelText: 'Address',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  _showSnackBar(context, "Your order is confirmed");
                  Future.delayed(Duration(seconds: 4), () {
                    Navigator.of(context).pop();
                  });
                },
                child: Text('Submit'),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  _showSnackBar(context, "Information has been saved");
                },
                child: Text('Save Credentials'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
